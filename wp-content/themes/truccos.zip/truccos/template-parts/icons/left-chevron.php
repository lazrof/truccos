<svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17">
    <g fill="none" fill-rule="evenodd">
        <g stroke="#979797" stroke-width="2">
            <g>
                <g>
                    <path d="M8 0L0 7.989 8 14.878" transform="translate(-121.000000, -1793.000000) translate(123.000000, 1450.000000) translate(0.000000, 343.658746)"/>
                </g>
            </g>
        </g>
    </g>
</svg>
