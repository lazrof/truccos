<svg xmlns="http://www.w3.org/2000/svg" width="11" height="17" viewBox="0 0 11 17">
    <g fill="none" fill-rule="evenodd">
        <g stroke="#979797" stroke-width="2">
            <g>
                <g>
                    <path d="M1194 0L1186 7.989 1194 14.878" transform="translate(-1308.000000, -1793.000000) translate(123.000000, 1450.000000) translate(0.000000, 343.658746) translate(1190.000000, 7.438910) scale(-1, 1) translate(-1190.000000, -7.438910)"/>
                </g>
            </g>
        </g>
    </g>
</svg>
